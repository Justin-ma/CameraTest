﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;
using AForge.Video.DirectShow;

namespace CameraTest
{
    public partial class Form1 : Form
    {
        public FilterInfoCollection Cameras = null;
        public VideoCaptureDevice Cam = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "开启摄像头")
            {

                button1.Text = "关闭摄像头";

                Cam.Start();   

            }
            else
            {

                button1.Text = "开启摄像头";

                Cam.Stop();

            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Enabled = false;

            try
            {

                //1、获取并枚举所有摄像头设备

                Cameras = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                //2、判断设备个数，选择某一设备

                if (Cameras.Count > 0)
                {

                    button1.Enabled = true;

                    Cam = new VideoCaptureDevice(Cameras[0].MonikerString);
                    Cam.VideoResolution = Cam.VideoCapabilities[0];
                    Cam.NewFrame += Cam_NewFrame;

                }
                else
                {

                    MessageBox.Show("未找到视频输入设备！");

                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());

            }

        }

        ///<summary>

        ///摄像头设备Cam的NewFrame事件处理程序

        ///用于实时显示捕获的视频流

        ///</summary>

        ///<paramname="sender"></param>

        ///<paramname="eventArgs"></param>

        private void Cam_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {

            pictureBox1.Image = (Bitmap)eventArgs.Frame.Clone();           
        }


        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Cam != null && Cam.IsRunning)
            {

                Cam.Stop();

            }

        }
    }
}
